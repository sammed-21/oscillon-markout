Fynd AMM ETH/USDG on Robinhood Chain: LP returns vs holding, 2026-10-02 to 2026-11-11 (UTC)
Every LP position since the pool started, to block 111,478,410 (2026-11-11 05:53 UTC).

Files
  Fynd_LP_returns_2026-11-11.pdf                               the report (1 page of text + 1 chart page)
  fynd_eth_usdg_lp_positions_2026-10-02_to_2026-11-11.csv      one row per LP position, 174 rows
  fynd_eth_usdg_lp_owners_2026-10-02_to_2026-11-11.csv         one row per LP, 8 rows (sums of the positions file)
  fynd_eth_usdg_lp_loss_split_2026-10-06_to_2026-11-11.csv     where LP vs hold comes from, by who traded (swaps start Oct 6)
  fynd_eth_usdg_bot_price_lag_2026-10-06_to_2026-11-11.csv     how stale the price is that the bot moves the pool to

Method
  LP   = what a position paid out (withdrawals + fees collected) + what it still holds (principal + uncollected fees)
  hold = the tokens it deposited, never put in the pool
  Both valued at Binance ETHUSDC (1 s close) at the position's end: its last withdrawal, or the snapshot if still open.
  LP - hold = fees + impermanent loss. USDG is taken as $1.

Positions file columns
  position_id                       Ekubo position salt; nft_id is the Ekubo Positions NFT that holds it
  owner                             holder of the NFT. "via 0x0db596af..." = held through that contract, not the NFT
  still_open                        TRUE if it still had liquidity at the snapshot
  start_utc, end_utc, days_open     first deposit; last withdrawal or the snapshot
  range_low_usd, range_high_usd     the position's price range (USDG per ETH). Blank high = full range
  share_of_time_in_range            share of its life the pool price was inside the range
  eth/usdg_deposited                tokens put in
  eth/usdg_out_principal            tokens withdrawn, plus what is still in the position if open (fees excluded)
  eth/usdg_fees                     fees collected, plus uncollected fees if open
  cost_usd                          each deposit valued at Binance when it was made
  capital_days_usd                  cost basis x days open (a withdrawal removes its share of the cost basis)
  eth_price_at_end                  Binance price used for hold_value_usd and lp_value_usd
  hold_value_usd, lp_value_usd      the two sides above
  fees_usd, impermanent_loss_usd    lp_minus_hold_usd = fees_usd + impermanent_loss_usd
  lp_result_usd, hold_result_usd    lp_value_usd - cost_usd, hold_value_usd - cost_usd (these include ETH's own move)

Owners file: lp_minus_hold_per_1000_per_30d_usd = lp_minus_hold_usd / capital_days_usd x 30,000.

Summing lp_minus_hold_usd over either file gives the report's -$3,690.

Loss split file (revised Nov 11)
  Per swap, from the LPs' side (negative = LPs lost), with p_after the pool price the swap leaves and B0 / B12 the
  Binance price just before / 12 s after:
    fees_usd         fee the swap paid to LPs
    capture_usd      pool_eth_change x p_after + pool_usdg_change: the trader's gain valued at the price it left the pool at
    pool_lag_usd     pool_eth_change x (B0 - p_after): the pool still differs from Binance after the trade, so LPs took
                     on inventory at a stale price. A trader books this only if it hedges at Binance
    after_12s_usd    pool_eth_change x (B12 - B0): the market's move in the 12 s after the trade
    trader_net_own_view_usd   -(capture + fees): the trader's result in its own terms, before its costs elsewhere
  Drift row: later price moves to each position's end (the remainder). All rows add up to LP vs hold, -$3,690.
  All swaps are kept, including 67 that the Nov 10 markout report left out.

Bot price lag file
  For each of the bot's swaps, the gap between the pool price it leaves and Binance taken N seconds before the trade
  (median, bp). The smallest gap, at ~15 s, is roughly how stale the bot's target price is.
