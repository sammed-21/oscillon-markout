Fynd AMM ETH/USDG on Robinhood Chain: LP returns vs holding, 2026-10-02 to 2026-11-13 (UTC)
Every LP position since the pool started, to block 113,153,559 (2026-11-13 06:35 UTC).
Only this pool (Ekubo poolId 0xb67e0601...3546, extension 0x550cfe12...1d09): the other ETH/USDG pools on Ekubo are not in it.

Files
  Fynd_LP_returns_2026-11-13.pdf                               the report (2 pages of text + 1 chart page)
  fynd_eth_usdg_lp_positions_2026-10-02_to_2026-11-13.csv      one row per LP position, 179 rows
  fynd_eth_usdg_lp_owners_2026-10-02_to_2026-11-13.csv         one row per LP, 8 rows (sums of the positions file)
  fynd_eth_usdg_lp_loss_split_2026-10-06_to_2026-11-13.csv     LP vs hold split by the wallet that sent each swap (swaps start 2026-10-06)
  fynd_eth_usdg_bot_wallet_h_sensitivity.csv                   bot wallet's capture for h = 0 to 12 bp, with 95% intervals
  fynd_eth_usdg_bot_wallet_fee_sensitivity.csv                 LPs' result on the bot wallet's swaps at fees 0 to 15 bp

Method
  LP   = what a position paid out (withdrawals + fees collected) + what it still holds (principal + uncollected fees)
  hold = the tokens it deposited, never put in the pool
  Both valued at Binance ETHUSDC (1 s close) at the position's end: its last withdrawal, or the snapshot if still open.
  LP - hold = fees + impermanent loss. USDG is taken as $1. Open positions were read on chain at the snapshot block.

Positions file columns
  position_id                       Ekubo position salt; nft_id is the Ekubo Positions NFT that holds it
  owner                             holder of the NFT. "via 0x0db596af..." = held through that contract, not the NFT
  still_open                        TRUE if it still had liquidity at the snapshot
  start_utc, end_utc, days_open     first deposit; last withdrawal or the snapshot
  range_low_usd, range_high_usd     the position's price range (USDG per ETH). Blank high = full range
  share_of_time_in_range            share of its life the pool price was inside the range
  eth/usdg_deposited                tokens put in
  eth/usdg_out_principal            tokens withdrawn, plus what is still in the position if open (fees excluded)
  eth/usdg_fees                     fees collected, plus uncollected fees if open
  cost_usd                          each deposit valued at Binance when it was made
  capital_days_usd                  cost basis x days open (a withdrawal removes its share of the cost basis)
  eth_price_at_end                  Binance price used for hold_value_usd and lp_value_usd
  hold_value_usd, lp_value_usd      the two sides above
  fees_usd, impermanent_loss_usd    lp_minus_hold_usd = fees_usd + impermanent_loss_usd
  lp_result_usd, hold_result_usd    lp_value_usd - cost_usd, hold_value_usd - cost_usd (these include ETH's own move)

Owners file: lp_minus_hold_per_1000_per_30d_usd = lp_minus_hold_usd / capital_days_usd x 30,000.

Summing lp_minus_hold_usd over either file gives the report's −$3,925.

Loss split file
  Per swap, from the LPs' side, valued at Binance ETHUSDC 12 s after the swap (as in the Nov 10 markout report),
  grouped by the wallet that sent the swap:
    fees_to_lps_usd            fees the swaps paid to LPs (valued when paid)
    loss_at_binance_12s_usd    the LP side of the swaps at Binance 12 s later, before fees
    net_for_lps_usd            the two together
  Later price moves: the remainder, from 12 s after each swap to each position's end. All rows add up to LP vs hold,
  −$3,925. All swaps are kept, including those the Nov 10 markout report left out.
  The net on the bot wallet's swaps (−$3,422) is an upper bound on what that wallet captured, before its hedging
  and other costs. "Loss" is measured on the LPs' side; it is not what the counterparty earned.

h sensitivity file
  bot wallet's capture = loss on its swaps - fees it paid - h x its volume ($4,037 - $615 - h x $4.48M),
  where h is its cost per $ traded: hedging, exchange fees, gas, and any gap between its hedge price and Binance 12 s later.
  Zero at h = 7.6 bp. 95% intervals from resampling the 39 days (5,000 draws).

Fee sensitivity file
  lp_on_bot_wallet_swaps_usd = fee x the bot wallet's volume - loss on its swaps. lp_minus_hold_all_usd = the same,
  plus everything else unchanged. Assumes identical swaps at every fee: a transfer from the bot wallet to LPs, not a
  forecast of what would happen at that fee.

Checks
  Books close: the open positions on chain hold what every deposit, withdrawal, fee and swap adds up to.
  Every fee paid in reached LP positions (100.000%).
  Matches the Nov 10 markout report: positions inside its window (Oct 6 - Nov 5) are −$3,108 vs holding.
